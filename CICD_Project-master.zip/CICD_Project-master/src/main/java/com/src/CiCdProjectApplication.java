package com.src;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CiCdProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CiCdProjectApplication.class, args);
	}

}
